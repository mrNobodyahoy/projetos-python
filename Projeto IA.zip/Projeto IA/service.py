import random

def criarLabirinto(tamanho, parede):
    mapa = []
    for i in range(0, tamanho):
        x = []
        for j in range (0, tamanho):
             num1 = random.randint(0, 1)
             if num1 == 1:
                x.append(5)
             else: 
                x.append(2)
        mapa.append(x)
    
    for i in range(parede):
        aleatoriolinha = random.randint(0, tamanho-1)
        aleatoriocoluna = random.randint(0, tamanho-1)
        if (aleatoriolinha, aleatoriocoluna) != (0, 0) and (aleatoriolinha, aleatoriocoluna) != (tamanho - 1, tamanho - 1):
         mapa[aleatoriolinha][aleatoriocoluna] = -1

    mapa[0][0] = 'A' 
    mapa[tamanho - 1][tamanho - 1] = 'B'

    print('Labirinto') 

    for i in range(0, tamanho):
         for j in range (0, tamanho):
             print(mapa[i][j], end = ' ')
         print()
    # mapa[tamanho -1][tamanho -1] = 'B'
    return mapa


def calcularDistancia(linhaAtual, colunaAtual, proximaLinha, proximaColuna):
        diferencaLinha = linhaAtual - proximaLinha
        diferencaColuna = colunaAtual - proximaColuna

        if diferencaLinha < 0:
            diferencaLinha = diferencaLinha * -1

        if diferencaColuna < 0:
            diferencaColuna = diferencaColuna * -1

        return diferencaLinha + diferencaColuna

def avaliarVizinho(novaLinha, novaColuna, custoAcumulado, noPai, pontoFinal, mapa, mapaNovo, matrizPai, fila):
    terreno = mapa[novaLinha][novaColuna]
    
    if terreno == -1:
        return
        
    if terreno == 'B' or terreno == 'A':
        custoDoPasso = 0
    else:
        custoDoPasso = terreno 
        
    novoCustoAcumulado = custoAcumulado + custoDoPasso

    nunca_visitado = (mapaNovo[novaLinha][novaColuna] == 0 and (novaLinha, novaColuna) != (0,0))
    caminho_mais_barato = (mapaNovo[novaLinha][novaColuna] != 0 and novoCustoAcumulado < mapaNovo[novaLinha][novaColuna])
    
    if nunca_visitado or caminho_mais_barato:
        
        mapaNovo[novaLinha][novaColuna] = novoCustoAcumulado
        matrizPai[novaLinha][novaColuna] = noPai
        
        estimativa = calcularDistancia(novaLinha, novaColuna, pontoFinal[0], pontoFinal[1])
        
        custoTotal = novoCustoAcumulado + estimativa
        
        fila.append((custoTotal, novoCustoAcumulado, (novaLinha, novaColuna)))


def exibirResultados(pontoFinal, nosExpandidos, tempoMs, matrizPai, mapa):
    caminho = []
    atual = pontoFinal

    while atual is not None:
        caminho.append(atual)
        atual = matrizPai[atual[0]][atual[1]]
      
    caminho.reverse()
    custoTotal = 0
    
    custoAcumulado = 0
    for coordenada in caminho:
        linha = coordenada[0]
        coluna = coordenada[1]
        valorTerreno = mapa[linha][coluna]

        if isinstance(valorTerreno, int) and valorTerreno != -1:
            custoAcumulado += valorTerreno
    
    print('Caminhos encontrados: ', caminho)
    print ('Nós expandidos: ', nosExpandidos)
    print('Tempo de execução:', tempoMs, 'milissegundos')
    print('Custo Acumulado: ', custoAcumulado)